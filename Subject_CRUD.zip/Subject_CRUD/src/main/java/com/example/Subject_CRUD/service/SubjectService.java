package com.example.Subject_CRUD.service;

import java.util.List;

import com.example.Subject_CRUD.entity.Subject1;

public interface SubjectService {
	
	Subject1 addSubject(Subject1 subject);
	
	List<Subject1> getSubjets();
	
	void deleteSubject(int id);
	
	Subject1 updateSubject(int id, Subject1 subject);
	
}
