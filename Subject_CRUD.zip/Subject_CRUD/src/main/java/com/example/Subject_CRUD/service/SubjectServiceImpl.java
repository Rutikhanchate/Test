package com.example.Subject_CRUD.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Subject_CRUD.dao.SubjectRepository;
import com.example.Subject_CRUD.entity.Subject1;

@Service
public class SubjectServiceImpl implements SubjectService{
	
	@Autowired
	SubjectRepository subrepo;
	
	
	@Override
	public Subject1 addSubject(Subject1 subject) {
		// TODO Auto-generated method stub
		return subrepo.save(subject);
	}


	@Override
	public List<Subject1> getSubjets() {
		// TODO Auto-generated method stub
		return subrepo.findAll();
	}


	@Override
	public void deleteSubject(int id) {
		// TODO Auto-generated method stub
		Subject1 subject = subrepo.findById(id).orElse(null);
		subrepo.delete(subject);
	}


	@Override
	public Subject1 updateSubject(int id, Subject1 subjectDet) {
		// TODO Auto-generated method stub
		Subject1 subject = subrepo.findById(id).orElse(null);
		
		subject.setName(subjectDet.getName());
		subject.setCode(subjectDet.getCode());
		subject.setPractical(subject.getPractical());
		
		return subrepo.save(subject);
	}

}
