package com.example.Subject_CRUD.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Subject1 {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String code;
	private String practical;
	
	public Subject1() {
		// TODO Auto-generated constructor stub
	}

	public Subject1(int id, String name, String code, String practical) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
		this.practical = practical;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getPractical() {
		return practical;
	}

	public void setPractical(String practical) {
		this.practical = practical;
	}
	
}
