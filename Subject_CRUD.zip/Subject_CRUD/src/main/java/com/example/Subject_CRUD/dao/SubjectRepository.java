package com.example.Subject_CRUD.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Subject_CRUD.entity.Subject1;

public interface SubjectRepository extends JpaRepository<Subject1, Integer>{

}
