package com.example.Subject_CRUD.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Subject_CRUD.entity.Subject1;
import com.example.Subject_CRUD.service.SubjectServiceImpl;

@RestController
@CrossOrigin("*")
public class SubjectController {
	
	@Autowired
	SubjectServiceImpl subserv;
	
	@PostMapping("/addSubject")
	public Subject1 addSubject(@RequestBody Subject1 subject) {
		return subserv.addSubject(subject);
	}
	
	@GetMapping("/getSubject")
	public List<Subject1> getSubjects(){
		return subserv.getSubjets();
	}
	
	@DeleteMapping("/deleteSubject/{id}")
	public String deleteSubject(@PathVariable int id) {
		subserv.deleteSubject(id);
		return "record deleted successfully ...";
	}
	
	
	@PutMapping("/updateSubject/{id}")
	public Subject1 updateSubject1(@PathVariable int id, @RequestBody Subject1 subject) {
		return subserv.updateSubject(id, subject);
	}

	
}
