package com.example.Subject_CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubjectCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
